# ATM_management_system
This is one of our mini project done during 6th semester, file structure with c++. It is used to keep record of  ATM transactions
