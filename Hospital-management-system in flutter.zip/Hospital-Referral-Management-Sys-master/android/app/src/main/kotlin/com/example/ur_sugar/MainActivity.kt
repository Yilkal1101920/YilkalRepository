package com.example.ur_sugar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
