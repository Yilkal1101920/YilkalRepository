class GeneralResponse {
  int? status;
  String? message;
  dynamic data;
}
