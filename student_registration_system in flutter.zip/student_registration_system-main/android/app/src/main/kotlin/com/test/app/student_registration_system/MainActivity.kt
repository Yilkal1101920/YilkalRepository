package com.test.app.student.registration.system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
