class Product{
    constructor(id , name, desc, price, url , color){
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.price = price;
        this.url = url;
        this.color = color;
        this.markForDelete=false;
    }
}
//calls many times so n objects will be created so this method of claasical approach