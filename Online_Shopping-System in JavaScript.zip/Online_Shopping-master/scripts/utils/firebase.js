  var firebaseConfig = {
    apiKey: "AIzaSyCBpqAjztHTw41QANOA5SDDzllQCwPXMms",
    authDomain: "online-shopping-f3553.firebaseapp.com",
    databaseURL: "https://online-shopping-f3553.firebaseio.com",
    projectId: "online-shopping-f3553",
    storageBucket: "",
    messagingSenderId: "165849576200",
    appId: "1:165849576200:web:4f24d10418ac9d9d"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
