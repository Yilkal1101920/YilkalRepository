class User{
    constructor(id,pass){
        this.id=id;
        this.pass=pass;
    }
}