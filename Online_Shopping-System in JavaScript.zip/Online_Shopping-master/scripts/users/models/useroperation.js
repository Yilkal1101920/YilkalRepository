const useroperation={
    user:[],
    add(users){
        this.user.push(users);
        console.log('you enterd useroperation');
    }

}