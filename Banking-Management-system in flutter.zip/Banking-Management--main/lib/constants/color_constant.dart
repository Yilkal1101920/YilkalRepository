import 'dart:ui';

const kBlueColor = Color(0xFF1E1E99);
const kTwentyBlueColor = Color(0x201E1E99);
const kPinkColor = Color(0xFFFF70A3);
const kWhiteColor = Color(0xFFFFFFFF);
const kBlackColor = Color(0xFF3A3A3A);
const kTenBlackColor = Color(0x10000000);
const kBackgroundColor = Color(0xFFFAFAFA);
const kGreyColor = Color(0xff8A959E);