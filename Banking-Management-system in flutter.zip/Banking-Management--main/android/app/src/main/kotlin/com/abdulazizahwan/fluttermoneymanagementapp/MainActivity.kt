package com.abdulazizahwan.fluttermoneymanagementapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
